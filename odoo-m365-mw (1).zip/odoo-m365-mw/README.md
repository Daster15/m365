# odoo-m365-mw

Dwukierunkowa integracja Odoo 17 (odoo.sh) ↔ Microsoft 365, z middleware za NAT-em.

* **Odoo → Outlook**: urlop zatwierdzony w Odoo (`hr.leave`) staje się eventem „Out of office” w kalendarzu pracownika. Zmiana dat aktualizuje event, a odmowa, anulowanie lub usunięcie urlopu usuwa go.
* **Outlook → Odoo**: eventy z kalendarza Outlook wybranych użytkowników są tworzone, aktualizowane i usuwane w kalendarzu Odoo.

Dwie części:

| | Gdzie | Co robi |
|---|---|---|
| `addons/ltech_m365_bridge` | odoo.sh | outbox zmian urlopów, REST API `/m365/v1/*`, zapis eventów z Outlooka, status synchronizacji w formularzu urlopu |
| `mw/` | Ubuntu za NAT-em | **wyłącznie wychodzące** HTTPS: odpytuje Odoo (outbox) i Graph (delta), lokalna kolejka z retry |

## Dlaczego działa za NAT-em

Ani Odoo, ani Microsoft nigdy nie łączą się z middleware. Kierunek jest zawsze jeden: middleware → odoo.sh i middleware → Graph.

```
              ┌──────────── middleware (za NAT, tylko ruch wychodzący) ────────────┐
 odoo.sh      │                                                                     │   Microsoft 365
 ┌────────┐   │  poller (30 s)        kolejka SQLite        worker                  │   ┌────────────┐
 │ hr.leave├─►│  GET  /outbox    ──►  job (retry,     ──►   POST/PATCH/DELETE ─────┼──►│ Outlook    │
 │ hooks  │   │  POST /outbox/ack     backoff,              /users/{upn}/events     │   │ calendar   │
 │   ▼    │   │  POST /leave/status ◄─ status ◄──────────── (wynik/błąd)            │   │            │
 │ outbox │   │                                                                     │   │            │
 │        │   │  inbound (120 s)                                                    │   │            │
 │calendar│◄──┤  POST /calendar/events ◄── normalize ◄── GET calendarView/delta ◄──┼───┤            │
 │ .event │   │  GET  /users (kto ma m365_sync)                                     │   └────────────┘
 └────────┘   └─────────────────────────────────────────────────────────────────────┘
```

Graph webhooks (change notifications) wymagają publicznego endpointu, więc ich nie używamy, tylko delta query. Opóźnienie Outlook → Odoo to najwyżej `INBOUND_INTERVAL`.

## Addon `ltech_m365_bridge` (Odoo 17)

* `hr.leave` create/write/unlink → wiersz w `m365.outbox` w tej samej transakcji, więc nic nie ginie. Dodatkowo cron co 15 min skanuje `write_date` jako siatkę bezpieczeństwa.
* REST API, autoryzacja `Authorization: Bearer <API key Odoo>`, użytkownik musi mieć grupę **M365 Bridge API**:

| Metoda | Ścieżka | |
|---|---|---|
| GET | `/m365/v1/ping` | test połączenia |
| GET | `/m365/v1/outbox?limit=200` | oczekujące zmiany |
| POST | `/m365/v1/outbox/ack` | `{"ids": [...]}` |
| GET | `/m365/v1/leave/<id>` | urlop + `employee.work_email/tz` (albo `null`, jeśli usunięty) |
| POST | `/m365/v1/leave/status` | wynik synchronizacji → widoczny na formularzu urlopu |
| GET | `/m365/v1/users` | użytkownicy z zaznaczonym „Import Outlook calendar” |
| POST | `/m365/v1/calendar/events` | `{"upn": ..., "items": [...]}` upsert/delete (idempotentne) |

* Eventy z Outlooka trafiają do `calendar.event` z polami `m365_event_id`/`m365_upn`, właściciel i uczestnik to użytkownik. Kontekst `dont_notify` + `no_mail_to_attendees`: bez zaproszeń mailowych i bez odbijania do Outlooka przez natywny `microsoft_calendar`, jeśli jest zainstalowany.
* Menu: Ustawienia → Techniczne → Microsoft 365 Bridge (outbox, statusy).

**Instalacja**: wrzuć `addons/ltech_m365_bridge` do repo odoo.sh, zainstaluj moduł. Potem:
1. Utwórz użytkownika technicznego (np. `mw@ltech.dk`, typ Internal User) i dodaj go do grupy **M365 Bridge API**.
2. Zaloguj się jako on (albo „Zmień użytkownika”) → Preferencje → Bezpieczeństwo konta → **New API Key**. Klucz trafia do `ODOO_API_KEY`.
3. Użytkownikom, których kalendarz ma się importować: Ustawienia → Użytkownicy → zakładka *Microsoft 365* → *Import Outlook calendar*.

## Microsoft 365 (Christian)

1. App registration w Entra ID + client secret (zapisz datę wygaśnięcia).
2. Graph **Application** permission `Calendars.ReadWrite` + admin consent.
3. **Koniecznie** RBAC for Applications w Exchange Online (albo Application Access Policy) ograniczające aplikację do grupy pracowników.

Mailbox = `hr.employee.work_email` (urlopy) i `res.users.email`/`login` (import). Muszą być równe UPN w M365.

## Middleware (Ubuntu)

```bash
sudo useradd -r -s /usr/sbin/nologin odoo-mw
sudo mkdir -p /opt/odoo-m365-mw && sudo cp -r mw requirements.txt /opt/odoo-m365-mw/
cd /opt/odoo-m365-mw
sudo python3 -m venv venv && sudo venv/bin/pip install -r requirements.txt
sudo cp .env.example /etc/odoo-m365-mw.env && sudo chmod 600 /etc/odoo-m365-mw.env   # uzupełnij
sudo cp deploy/odoo-m365-mw.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now odoo-m365-mw
journalctl -u odoo-m365-mw -f
```

Test połączenia z Odoo: `curl -H "Authorization: Bearer $KEY" https://ltech.odoo.com/m365/v1/ping`

### Odporność na awarie

| Sytuacja | Zachowanie |
|---|---|
| M365 niedostępny / 429 / 5xx | job wraca do kolejki z backoffem 30 s → 1 h (respektuje `Retry-After`), worker pauzuje cały, inbound pomija cykl |
| odoo.sh niedostępny (rebuild = 502/503) | outbox czeka w Odoo, delta token nie przesuwa się, po powrocie wszystko się dogrywa |
| Restart / crash middleware | joby `running` wracają do kolejki; outbox ackowany dopiero po zapisie do lokalnej kolejki |
| Utrata `state.db` | eventy urlopowe odnajdywane po extended property `OdooLeaveId` (bez duplikatów), delta robi pełną resynchronizację, upsert w Odoo idempotentny |
| Wiele zmian urlopu podczas awarii | koalescencja: jeden job na urlop, worker czyta aktualny stan → jedna operacja w Graph |
| Błąd trwały (brak `work_email`, 403 RBAC) | job `dead`, błąd widoczny na formularzu urlopu w Odoo |
| Wygasły delta token (410) | automatyczna pełna resynchronizacja mailboxa |

### Ograniczenia (świadome)

* Outlook → Odoo jest jednokierunkowe: edycja zaimportowanego eventu w Odoo zostanie nadpisana przy następnej zmianie w Outlooku.
* Wydarzenia cykliczne przychodzą jako pojedyncze wystąpienia (tak zwraca `calendarView`).
* Okno importu: `DELTA_PAST_DAYS` wstecz, `DELTA_FUTURE_DAYS` w przód, przesuwane co `DELTA_RESET_DAYS`.
* Eventy urlopowe (kategoria „Odoo Time Off”) nie są importowane z powrotem do Odoo.
* Jeśli na tych samych użytkownikach działa też `ms_calendar_async` / natywny `microsoft_calendar`, eventy się zdublują. Wybierz jeden mechanizm na użytkownika.

### Operacyjnie

```bash
DB=/var/lib/odoo-m365-mw/state.db
sqlite3 $DB "SELECT status, COUNT(*) FROM job GROUP BY status"
sqlite3 $DB "SELECT leave_id, attempts, last_error FROM job WHERE status='dead'"
sqlite3 $DB "UPDATE job SET status='pending', attempts=0, next_run_at=0 WHERE status='dead'"   # po naprawie
sqlite3 $DB "DELETE FROM delta_state WHERE upn='anna@ltech.dk'"                               # pełny reimport
```

## Testy

```bash
python3 -m unittest discover -s tests      # middleware, offline (13 testów)
```
Addon został sprawdzony na czystym Odoo 17.0 + PostgreSQL 16: instalacja, wszystkie endpointy prawdziwym klientem `mw/odoo.py`, hooki refuse/unlink, 401/403, brak maili do uczestników.
