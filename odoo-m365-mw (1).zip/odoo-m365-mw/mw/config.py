import os
from dataclasses import dataclass, field


def _env(name, default=None, cast=str):
    v = os.environ.get(name, default)
    if v is None:
        raise RuntimeError(f"Missing env var {name}")
    return cast(v)


@dataclass(frozen=True)
class Config:
    # Odoo (odoo.sh) – ltech_m365_bridge REST API, technical user's API key
    odoo_url: str = field(default_factory=lambda: _env("ODOO_URL").rstrip("/"))
    odoo_api_key: str = field(default_factory=lambda: _env("ODOO_API_KEY"))

    # Microsoft Graph – app-only (client credentials)
    ms_tenant_id: str = field(default_factory=lambda: _env("MS_TENANT_ID"))
    ms_client_id: str = field(default_factory=lambda: _env("MS_CLIENT_ID"))
    ms_client_secret: str = field(default_factory=lambda: _env("MS_CLIENT_SECRET"))

    # Local state
    db_path: str = field(default_factory=lambda: _env("MW_DB_PATH", "/var/lib/odoo-m365-mw/state.db"))

    # Behaviour
    poll_interval: int = field(default_factory=lambda: _env("POLL_INTERVAL", "60", int))
    outbox_batch: int = field(default_factory=lambda: _env("OUTBOX_BATCH", "200", int))
    # Outlook -> Odoo
    inbound_enabled: bool = field(default_factory=lambda: _env("INBOUND_ENABLED", "1") == "1")
    inbound_interval: int = field(default_factory=lambda: _env("INBOUND_INTERVAL", "120", int))
    delta_past_days: int = field(default_factory=lambda: _env("DELTA_PAST_DAYS", "30", int))
    delta_future_days: int = field(default_factory=lambda: _env("DELTA_FUTURE_DAYS", "365", int))
    delta_reset_days: int = field(default_factory=lambda: _env("DELTA_RESET_DAYS", "7", int))  # roll window
    users_refresh: int = field(default_factory=lambda: _env("USERS_REFRESH", "600", int))
    default_tz: str = field(default_factory=lambda: _env("DEFAULT_TZ", "Europe/Copenhagen"))
    max_attempts: int = field(default_factory=lambda: _env("MAX_ATTEMPTS", "200", int))
    event_sensitivity: str = field(default_factory=lambda: _env("EVENT_SENSITIVITY", "private"))
    subject_prefix: str = field(default_factory=lambda: _env("SUBJECT_PREFIX", "Time off"))
