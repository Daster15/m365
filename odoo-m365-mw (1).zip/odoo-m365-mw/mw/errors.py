class Transient(Exception):
    """Temporary failure (network, 5xx, 429, token) – retry later."""

    def __init__(self, msg, retry_after=None, source=None):
        super().__init__(msg)
        self.retry_after = retry_after  # seconds, if the server told us
        self.source = source            # "graph" | "odoo"


class Permanent(Exception):
    """Will not fix itself by retrying (bad data, 403, 400)."""
