import logging
import os
import signal
import sys
import threading

from . import inbound, poller, worker
from .config import Config
from .graph import Graph
from .odoo import Odoo
from .store import Store


def main():
    logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", stream=sys.stdout)
    cfg = Config()
    os.makedirs(os.path.dirname(cfg.db_path), exist_ok=True)
    Store(cfg.db_path).init()

    stop = threading.Event()
    signal.signal(signal.SIGTERM, lambda *_: stop.set())
    signal.signal(signal.SIGINT, lambda *_: stop.set())

    # each thread gets its own sqlite connection and HTTP clients
    threads = [
        threading.Thread(target=poller.run, name="poller",
                         args=(Store(cfg.db_path), Odoo(cfg), cfg, stop)),
        threading.Thread(target=worker.run, name="worker",
                         args=(Store(cfg.db_path), Odoo(cfg), Graph(cfg), cfg, stop)),
    ]
    if cfg.inbound_enabled:
        threads.append(threading.Thread(target=inbound.run, name="inbound",
                                        args=(Store(cfg.db_path), Odoo(cfg), Graph(cfg), cfg, stop)))
    for t in threads:
        t.start()
    logging.getLogger("mw").info("started")
    for t in threads:
        t.join()
    logging.getLogger("mw").info("stopped")


if __name__ == "__main__":
    main()
