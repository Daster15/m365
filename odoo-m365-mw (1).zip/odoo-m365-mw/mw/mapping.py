"""hr.leave → Graph event payload."""
import hashlib
import json
from datetime import date, timedelta

from .graph import LEAVE_PROP_ID

LEAVE_CATEGORY = "Odoo Time Off"   # marks events we created – skipped when importing Outlook -> Odoo


def build_event(leave, employee, cfg):
    leave_type = leave["holiday_status_id"][1] if leave.get("holiday_status_id") else ""
    body = {
        "subject": f"{cfg.subject_prefix}: {leave_type}".strip(": "),
        "showAs": "oof",
        "sensitivity": cfg.event_sensitivity,
        "isReminderOn": False,
        "categories": [LEAVE_CATEGORY],
        "singleValueExtendedProperties": [{"id": LEAVE_PROP_ID, "value": str(leave["id"])}],
    }
    if leave.get("request_unit_half") or leave.get("request_unit_hours"):
        # Partial day: Odoo stores date_from/date_to as naive UTC "YYYY-MM-DD HH:MM:SS"
        body["isAllDay"] = False
        body["start"] = {"dateTime": leave["date_from"].replace(" ", "T"), "timeZone": "UTC"}
        body["end"] = {"dateTime": leave["date_to"].replace(" ", "T"), "timeZone": "UTC"}
    else:
        # All-day: midnight to midnight in the user's tz, end is exclusive (day after last day)
        tz = (employee or {}).get("tz") or cfg.default_tz
        d_from = date.fromisoformat(leave["request_date_from"])
        d_to = date.fromisoformat(leave["request_date_to"]) + timedelta(days=1)
        body["isAllDay"] = True
        body["start"] = {"dateTime": f"{d_from}T00:00:00", "timeZone": tz}
        body["end"] = {"dateTime": f"{d_to}T00:00:00", "timeZone": tz}
    return body


def payload_hash(body):
    return hashlib.sha256(json.dumps(body, sort_keys=True).encode()).hexdigest()


def wants_event(leave):
    return bool(leave) and leave.get("active", True) and leave.get("state") == "validate"
