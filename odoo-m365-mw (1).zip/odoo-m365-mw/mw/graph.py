"""Microsoft Graph calendar client, app-only auth."""
import httpx
import msal

from .errors import Permanent, Transient

# Fixed extended property – lets us find "our" event in Outlook even if local state is lost
LEAVE_PROP_ID = "String {6b1d3c0e-8a42-4f2b-9d7e-3c5a1f0b7e21} Name OdooLeaveId"


class Graph:
    def __init__(self, cfg):
        self.app = msal.ConfidentialClientApplication(
            cfg.ms_client_id,
            authority=f"https://login.microsoftonline.com/{cfg.ms_tenant_id}",
            client_credential=cfg.ms_client_secret,
        )
        self.http = httpx.Client(base_url="https://graph.microsoft.com/v1.0", timeout=30)

    def _token(self):
        try:
            r = self.app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])  # cached by msal
        except Exception as e:  # network error talking to login.microsoftonline.com
            raise Transient(f"token: {e!r}", source="graph")
        if "access_token" not in r:
            err = r.get("error", "")
            if err in ("invalid_client", "unauthorized_client", "invalid_request"):
                raise Permanent(f"token: {r.get('error_description')}")
            raise Transient(f"token: {err} {r.get('error_description')}", source="graph")
        return r["access_token"]

    def _req(self, method, url, **kw):
        headers = {"Authorization": f"Bearer {self._token()}", **kw.pop("headers", {})}
        try:
            r = self.http.request(method, url, headers=headers, **kw)
        except httpx.TransportError as e:
            raise Transient(f"graph transport: {e!r}", source="graph")
        if r.status_code in (429, 500, 502, 503, 504) or r.status_code == 401:
            raise Transient(f"graph HTTP {r.status_code}: {r.text[:200]}", retry_after=_ra(r), source="graph")
        return r

    def find_by_leave(self, upn, leave_id):
        flt = (f"singleValueExtendedProperties/Any(ep: ep/id eq '{LEAVE_PROP_ID}' "
               f"and ep/value eq '{leave_id}')")
        r = self._req("GET", f"/users/{upn}/events", params={"$filter": flt, "$select": "id"})
        _check(r)
        items = r.json().get("value", [])
        return items[0]["id"] if items else None

    def create(self, upn, body):
        r = self._req("POST", f"/users/{upn}/events", json=body)
        _check(r)
        return r.json()["id"]

    def update(self, upn, event_id, body):
        """Returns False if the event no longer exists (user deleted it)."""
        r = self._req("PATCH", f"/users/{upn}/events/{event_id}", json=body)
        if r.status_code == 404:
            return False
        _check(r)
        return True

    def delete(self, upn, event_id):
        r = self._req("DELETE", f"/users/{upn}/events/{event_id}")
        if r.status_code in (204, 404):
            return
        _check(r)


    def calendar_delta(self, upn, delta_link=None, start=None, end=None):
        """Yields (events, delta_link). delta_link is set only on the last page.
        Raises DeltaReset when the token is no longer valid → caller does a full resync."""
        headers = {"Prefer": 'odata.maxpagesize=100, outlook.timezone="UTC"'}
        if delta_link:
            url, params = delta_link, None
        else:
            url, params = f"/users/{upn}/calendarView/delta", {"startDateTime": start, "endDateTime": end}
        while url:
            r = self._req("GET", url, params=params, headers=headers)
            if r.status_code == 410 or (r.status_code == 400 and "syncstate" in r.text.lower()):
                raise DeltaReset(r.text[:200])
            _check(r)
            data = r.json()
            url, params = data.get("@odata.nextLink"), None
            yield data.get("value", []), data.get("@odata.deltaLink")


class DeltaReset(Exception):
    pass


def _check(r):
    if r.status_code >= 400:
        # 403 = missing permission / RBAC scope, 404 on mailbox = wrong UPN, 400 = bad payload
        raise Permanent(f"graph HTTP {r.status_code}: {r.text[:300]}")


def _ra(r):
    try:
        return int(r.headers.get("Retry-After"))
    except (TypeError, ValueError):
        return None
