"""Local state + job queue in SQLite (WAL). One connection per thread."""
import sqlite3
import time

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);

-- last known state of each hr.leave we have processed
CREATE TABLE IF NOT EXISTS leave_event (
    leave_id     INTEGER PRIMARY KEY,
    write_date   TEXT,            -- Odoo write_date at last processing
    upn          TEXT,            -- mailbox the event lives in
    ms_event_id  TEXT,            -- NULL = no event in Outlook
    payload_hash TEXT,
    last_error   TEXT,            -- set when job went 'dead'
    reported     INTEGER NOT NULL DEFAULT 0,  -- status pushed to Odoo?
    updated_at   REAL NOT NULL
);

-- Graph calendarView delta token per mailbox (Outlook -> Odoo)
CREATE TABLE IF NOT EXISTS delta_state (
    upn          TEXT PRIMARY KEY,
    delta_link   TEXT NOT NULL,
    window_start REAL NOT NULL,   -- when the delta window was initialised
    updated_at   REAL NOT NULL
);

-- queue: at most one pending job per leave (coalescing – worker reads fresh data)
CREATE TABLE IF NOT EXISTS job (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    leave_id    INTEGER NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending',   -- pending | running | done | dead
    attempts    INTEGER NOT NULL DEFAULT 0,
    next_run_at REAL NOT NULL,
    last_error  TEXT,
    created_at  REAL NOT NULL,
    updated_at  REAL NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS job_one_pending ON job(leave_id) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS job_due ON job(status, next_run_at);
"""


class Store:
    def __init__(self, path):
        # created in main thread, then owned by exactly one worker thread → check_same_thread off is safe
        self.c = sqlite3.connect(path, timeout=30, isolation_level=None, check_same_thread=False)  # autocommit
        self.c.row_factory = sqlite3.Row
        self.c.execute("PRAGMA busy_timeout=30000")

    def init(self):
        self.c.executescript(SCHEMA)
        # crash recovery: anything left 'running' goes back to the queue
        self.c.execute("UPDATE job SET status='pending', updated_at=? WHERE status='running'", (time.time(),))
        # if that collides with an existing pending job for the same leave, drop the duplicate
        self.c.execute("""DELETE FROM job WHERE status='pending' AND id NOT IN
                          (SELECT MIN(id) FROM job WHERE status='pending' GROUP BY leave_id)""")

    # --- kv ---
    def get(self, key, default=None):
        r = self.c.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

    def set(self, key, value):
        self.c.execute("INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                       (key, value))

    # --- leave_event ---
    def leave(self, leave_id):
        return self.c.execute("SELECT * FROM leave_event WHERE leave_id=?", (leave_id,)).fetchone()

    def save_leave(self, leave_id, write_date, upn, ms_event_id, payload_hash):
        self.c.execute("""
            INSERT INTO leave_event(leave_id, write_date, upn, ms_event_id, payload_hash, last_error,
                                    reported, updated_at)
            VALUES (?,?,?,?,?,NULL,0,?)
            ON CONFLICT(leave_id) DO UPDATE SET write_date=excluded.write_date, upn=excluded.upn,
                ms_event_id=excluded.ms_event_id, payload_hash=excluded.payload_hash,
                last_error=NULL, reported=0, updated_at=excluded.updated_at""",
                       (leave_id, write_date, upn, ms_event_id, payload_hash, time.time()))

    def mark_error(self, leave_id, error):
        self.c.execute("""
            INSERT INTO leave_event(leave_id, last_error, reported, updated_at) VALUES (?,?,0,?)
            ON CONFLICT(leave_id) DO UPDATE SET last_error=excluded.last_error, reported=0,
                updated_at=excluded.updated_at""", (leave_id, error[:2000], time.time()))

    def unreported(self, limit=500):
        return self.c.execute("SELECT leave_id, upn, ms_event_id, last_error, updated_at FROM leave_event "
                              "WHERE reported=0 LIMIT ?", (limit,)).fetchall()

    def mark_reported(self, rows):
        # only if not changed meanwhile (updated_at guard)
        self.c.executemany("UPDATE leave_event SET reported=1 WHERE leave_id=? AND updated_at=?",
                           [(r["leave_id"], r["updated_at"]) for r in rows])

    # --- delta (Outlook -> Odoo) ---
    def delta(self, upn):
        return self.c.execute("SELECT delta_link, window_start FROM delta_state WHERE upn=?", (upn,)).fetchone()

    def set_delta(self, upn, delta_link, window_start):
        self.c.execute("""INSERT INTO delta_state(upn, delta_link, window_start, updated_at) VALUES (?,?,?,?)
                          ON CONFLICT(upn) DO UPDATE SET delta_link=excluded.delta_link,
                          window_start=excluded.window_start, updated_at=excluded.updated_at""",
                       (upn, delta_link, window_start, time.time()))

    def drop_delta(self, upn):
        self.c.execute("DELETE FROM delta_state WHERE upn=?", (upn,))

    # --- queue ---
    def enqueue(self, leave_id):
        now = time.time()
        # if a pending job exists (maybe in backoff), leave it alone – it will read fresh data anyway
        self.c.execute("""INSERT INTO job(leave_id, next_run_at, created_at, updated_at) VALUES (?,?,?,?)
                          ON CONFLICT(leave_id) WHERE status='pending' DO NOTHING""",
                       (leave_id, now, now, now))

    def claim(self):
        now = time.time()
        self.c.execute("BEGIN IMMEDIATE")
        try:
            r = self.c.execute("""
                SELECT id, leave_id, attempts FROM job
                WHERE status='pending' AND next_run_at <= ?
                  AND leave_id NOT IN (SELECT leave_id FROM job WHERE status='running')
                ORDER BY next_run_at LIMIT 1""", (now,)).fetchone()
            if r:
                self.c.execute("UPDATE job SET status='running', attempts=attempts+1, updated_at=? WHERE id=?",
                               (now, r["id"]))
            self.c.execute("COMMIT")
        except Exception:
            self.c.execute("ROLLBACK")
            raise
        return r

    def done(self, job_id):
        self.c.execute("UPDATE job SET status='done', last_error=NULL, updated_at=? WHERE id=?", (time.time(), job_id))

    def retry(self, job_id, leave_id, delay, error):
        now = time.time()
        self.c.execute("BEGIN IMMEDIATE")
        try:
            # a newer pending job for this leave may have been enqueued meanwhile → just drop this one
            if self.c.execute("SELECT 1 FROM job WHERE leave_id=? AND status='pending'", (leave_id,)).fetchone():
                self.c.execute("UPDATE job SET status='done', last_error=?, updated_at=? WHERE id=?",
                               (f"superseded; {error}", now, job_id))
            else:
                self.c.execute("UPDATE job SET status='pending', next_run_at=?, last_error=?, updated_at=? WHERE id=?",
                               (now + delay, error, now, job_id))
            self.c.execute("COMMIT")
        except Exception:
            self.c.execute("ROLLBACK")
            raise

    def dead(self, job_id, error):
        self.c.execute("UPDATE job SET status='dead', last_error=?, updated_at=? WHERE id=?",
                       (error, time.time(), job_id))

    def purge_done(self, older_than_days=30):
        self.c.execute("DELETE FROM job WHERE status='done' AND updated_at < ?",
                       (time.time() - older_than_days * 86400,))
