"""Pulls the Odoo outbox and reports sync status back (outbound only – works behind NAT)."""
import logging

from .errors import Permanent, Transient

log = logging.getLogger("mw.poller")


def poll_once(store, odoo, cfg):
    total = 0
    while True:
        rows = odoo.outbox(limit=cfg.outbox_batch)
        if not rows:
            break
        for r in rows:
            if r["model"] == "hr.leave":
                store.enqueue(r["res_id"])
        # ack only after jobs are durable in the local queue
        odoo.ack([r["id"] for r in rows])
        total += len(rows)
        if len(rows) < cfg.outbox_batch:
            break
    if total:
        log.info("pulled %s outbox items", total)


def report_once(store, odoo):
    rows = store.unreported()
    if not rows:
        return
    odoo.report_status([{
        "leave_id": r["leave_id"], "upn": r["upn"], "event_id": r["ms_event_id"],
        "state": "error" if r["last_error"] else ("synced" if r["ms_event_id"] else "removed"),
        "error": r["last_error"],
    } for r in rows])
    store.mark_reported(rows)


def run(store, odoo, cfg, stop):
    while not stop.is_set():
        try:
            poll_once(store, odoo, cfg)
            report_once(store, odoo)
            store.purge_done()
        except Transient as e:
            log.warning("odoo unavailable: %s", e)
        except Permanent as e:
            log.error("poller: %s", e)
        except Exception:
            log.exception("poller crashed, continuing")
        stop.wait(cfg.poll_interval)
