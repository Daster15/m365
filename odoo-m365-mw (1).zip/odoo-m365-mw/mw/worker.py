"""Processes queued leaves: reads fresh state from Odoo, makes Outlook match it."""
import logging
import random
import time

from .errors import Permanent, Transient
from .mapping import build_event, payload_hash, wants_event

log = logging.getLogger("mw.worker")


def backoff(attempts, retry_after=None):
    base = min(30 * 2 ** (attempts - 1), 3600)          # 30s, 60s, 2m … capped at 1h
    delay = max(base, retry_after or 0)
    return delay + random.uniform(0, delay * 0.1)


def sync_leave(leave_id, store, odoo, graph, cfg):
    leave = odoo.read_leave(leave_id)          # None → deleted in Odoo
    rec = store.leave(leave_id)
    old_upn = rec["upn"] if rec else None
    old_eid = rec["ms_event_id"] if rec else None
    write_date = leave["write_date"] if leave else (rec["write_date"] if rec else None)

    if not wants_event(leave):
        if old_eid:
            graph.delete(old_upn, old_eid)
            log.info("leave %s: deleted event in %s", leave_id, old_upn)
        store.save_leave(leave_id, write_date, old_upn, None, None)
        return

    if not leave.get("employee_id"):
        raise Permanent("leave without employee")
    emp = leave.get("employee")
    upn = (emp or {}).get("work_email")
    if not upn:
        raise Permanent(f"employee {leave['employee_id'][1]!r} has no work_email")
    upn = upn.strip().lower()

    body = build_event(leave, emp, cfg)
    h = payload_hash(body)
    if old_eid and old_upn == upn and rec["payload_hash"] == h:
        store.save_leave(leave_id, write_date, upn, old_eid, h)   # nothing relevant changed
        return

    if old_eid and old_upn != upn:              # employee/email changed → move event
        graph.delete(old_upn, old_eid)
        old_eid = None

    eid = old_eid
    if eid and not graph.update(upn, eid, body):
        eid = None                              # user deleted it in Outlook → recreate
    if not eid:
        eid = graph.find_by_leave(upn, leave_id)    # protects against duplicates after a crash
        if eid:
            graph.update(upn, eid, body)
        else:
            eid = graph.create(upn, body)
    store.save_leave(leave_id, write_date, upn, eid, h)
    log.info("leave %s: event %s in %s", leave_id, "updated" if old_eid else "created/linked", upn)


def run(store, odoo, graph, cfg, stop):
    pause_until = 0.0
    while not stop.is_set():
        if time.time() < pause_until:                # circuit breaker: don't hammer a dead service
            stop.wait(min(5, pause_until - time.time()))
            continue
        job = store.claim()
        if not job:
            stop.wait(2)
            continue
        jid, leave_id, attempts = job["id"], job["leave_id"], job["attempts"] + 1
        try:
            sync_leave(leave_id, store, odoo, graph, cfg)
            store.done(jid)
        except Transient as e:
            delay = backoff(attempts, e.retry_after)
            if attempts >= cfg.max_attempts:
                store.dead(jid, f"transient x{attempts}: {e}")
                store.mark_error(leave_id, f"gave up after {attempts} attempts: {e}")
                log.error("leave %s: giving up after %s attempts: %s", leave_id, attempts, e)
            else:
                store.retry(jid, leave_id, delay, str(e))
                log.warning("leave %s: %s – retry in %.0fs (attempt %s)", leave_id, e, delay, attempts)
            # the service is most likely down for everyone → pause the whole worker, not just this job
            pause_until = time.time() + min(delay, 300)
        except Permanent as e:
            store.dead(jid, str(e))
            store.mark_error(leave_id, str(e))
            log.error("leave %s: permanent error: %s", leave_id, e)
        except Exception as e:  # bug – keep the job, back off
            store.retry(jid, leave_id, backoff(attempts), f"unexpected: {e!r}")
            log.exception("leave %s: unexpected error", leave_id)
