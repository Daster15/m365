"""Client for the ltech_m365_bridge REST API on odoo.sh (outbound calls only)."""
import httpx

from .errors import Permanent, Transient


class Odoo:
    def __init__(self, cfg):
        self.http = httpx.Client(base_url=f"{cfg.odoo_url}/m365/v1", timeout=30,
                                 headers={"Authorization": f"Bearer {cfg.odoo_api_key}"})

    def _req(self, method, path, **kw):
        try:
            r = self.http.request(method, path, **kw)
        except httpx.TransportError as e:
            raise Transient(f"odoo transport: {e!r}", source="odoo")
        if r.status_code == 429 or r.status_code >= 500:
            # odoo.sh answers 502/503 during rebuilds/upgrades
            raise Transient(f"odoo HTTP {r.status_code}: {r.text[:200]}", retry_after=_ra(r), source="odoo")
        if r.status_code >= 400:
            # 401/403: API key / group; 404: addon not installed; 400: bad data
            raise Permanent(f"odoo HTTP {r.status_code}: {r.text[:300]}")
        return r.json()

    # Odoo -> Outlook
    def outbox(self, limit=200):
        return self._req("GET", "/outbox", params={"limit": limit})["items"]

    def ack(self, ids):
        if ids:
            self._req("POST", "/outbox/ack", json={"ids": ids})

    def read_leave(self, leave_id):
        return self._req("GET", f"/leave/{leave_id}")["leave"]   # includes "employee": {work_email, tz}

    def report_status(self, items):
        if items:
            self._req("POST", "/leave/status", json={"items": items})

    # Outlook -> Odoo
    def users(self):
        return [u["upn"] for u in self._req("GET", "/users")["items"] if u["upn"]]

    def push_events(self, upn, items):
        return self._req("POST", "/calendar/events", json={"upn": upn, "items": items})


def _ra(r):
    try:
        return int(r.headers.get("Retry-After"))
    except (TypeError, ValueError):
        return None
