"""Outlook -> Odoo: per-mailbox Graph calendarView delta, pushed to the Odoo bridge API.

Pull only (Graph webhooks would need a public endpoint – we are behind NAT).
The new deltaLink is stored only after Odoo accepted all pages, so any failure just replays
from the previous token; the Odoo side upsert is idempotent.
"""
import logging
import time
from datetime import datetime, timedelta, timezone

from .errors import Permanent, Transient
from .graph import DeltaReset
from .mapping import LEAVE_CATEGORY

log = logging.getLogger("mw.inbound")


def normalize(ev):
    if "@removed" in ev:
        return {"id": ev["id"], "removed": True}
    if LEAVE_CATEGORY in (ev.get("categories") or []):
        return None                                   # our own time-off event – already in Odoo
    if ev.get("isCancelled"):
        return {"id": ev["id"], "removed": True}
    return {
        "id": ev["id"],
        "removed": False,
        "subject": ev.get("subject") or "",
        "start": ev["start"]["dateTime"][:19],        # UTC (Prefer: outlook.timezone="UTC")
        "end": ev["end"]["dateTime"][:19],
        "all_day": bool(ev.get("isAllDay")),
        "show_as": ev.get("showAs"),
        "sensitivity": ev.get("sensitivity"),
        "location": (ev.get("location") or {}).get("displayName") or "",
        "body_preview": ev.get("bodyPreview") or "",
    }


def sync_mailbox(upn, store, odoo, graph, cfg, now=None):
    now = now or time.time()
    st = store.delta(upn)
    link, window_start = (st["delta_link"], st["window_start"]) if st else (None, now)
    if link and now - window_start > cfg.delta_reset_days * 86400:
        link, window_start = None, now                # roll the date window forward
    kw = {}
    if not link:
        base = datetime.fromtimestamp(now, timezone.utc).replace(microsecond=0)
        kw = {"start": (base - timedelta(days=cfg.delta_past_days)).strftime("%Y-%m-%dT%H:%M:%SZ"),
              "end": (base + timedelta(days=cfg.delta_future_days)).strftime("%Y-%m-%dT%H:%M:%SZ")}
    stats = {"created": 0, "updated": 0, "deleted": 0}
    new_link = None
    for events, delta_link in graph.calendar_delta(upn, delta_link=link, **kw):
        items = [i for i in (normalize(e) for e in events) if i]
        for i in range(0, len(items), 100):
            res = odoo.push_events(upn, items[i:i + 100])
            for k in stats:
                stats[k] += res.get(k, 0)
        new_link = delta_link or new_link
    if new_link:
        store.set_delta(upn, new_link, window_start)
    if any(stats.values()):
        log.info("%s: %s", upn, stats)


def run(store, odoo, graph, cfg, stop):
    users, users_at = [], 0.0
    while not stop.is_set():
        try:
            if time.time() - users_at > cfg.users_refresh:
                users, users_at = odoo.users(), time.time()
            for upn in users:
                if stop.is_set():
                    break
                try:
                    sync_mailbox(upn, store, odoo, graph, cfg)
                except DeltaReset as e:
                    log.warning("%s: delta token invalid (%s) – full resync next cycle", upn, e)
                    store.drop_delta(upn)
                except Permanent as e:                # e.g. mailbox outside RBAC scope, no Odoo user
                    log.error("%s: %s", upn, e)
        except Transient as e:                        # Graph or Odoo down – skip the rest of this cycle
            log.warning("inbound paused: %s", e)
        except Exception:
            log.exception("inbound crashed, continuing")
        stop.wait(cfg.inbound_interval)
