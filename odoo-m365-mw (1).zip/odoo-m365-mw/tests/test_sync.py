"""Offline tests with fake Odoo bridge API / Graph: python3 -m unittest discover -s tests"""
import os
import sys
import tempfile
import threading
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
for k, v in dict(ODOO_URL="https://x", ODOO_API_KEY="k",
                 MS_TENANT_ID="t", MS_CLIENT_ID="c", MS_CLIENT_SECRET="s").items():
    os.environ.setdefault(k, v)

from mw import inbound, poller, worker  # noqa: E402
from mw.config import Config  # noqa: E402
from mw.errors import Transient  # noqa: E402
from mw.graph import DeltaReset  # noqa: E402
from mw.store import Store  # noqa: E402

EMP = {"name": "Anna", "work_email": "Anna@ltech.dk", "tz": "Europe/Copenhagen"}


class FakeOdoo:
    def __init__(self):
        self.leaves, self.outbox_rows, self.down = {}, [], False
        self.status, self.calendar, self._oid = {}, {}, 0

    def _chk(self):
        if self.down:
            raise Transient("odoo down", source="odoo")

    # simulates what the addon's hr.leave create/write/unlink hooks do
    def touch(self, lid, leave_obj=None, deleted=False):
        if deleted:
            self.leaves.pop(lid, None)
        else:
            self.leaves[lid] = leave_obj
        self._oid += 1
        self.outbox_rows.append({"id": self._oid, "model": "hr.leave", "res_id": lid,
                                 "event": "deleted" if deleted else "changed", "payload": None, "done": False})

    def outbox(self, limit=200):
        self._chk()
        return [r for r in self.outbox_rows if not r["done"]][:limit]

    def ack(self, ids):
        self._chk()
        for r in self.outbox_rows:
            if r["id"] in ids:
                r["done"] = True

    def read_leave(self, lid):
        self._chk()
        return dict(self.leaves[lid]) if lid in self.leaves else None

    def report_status(self, items):
        self._chk()
        for i in items:
            self.status[i["leave_id"]] = i

    def users(self):
        self._chk()
        return ["anna@ltech.dk"]

    def push_events(self, upn, items):
        self._chk()
        st = {"created": 0, "updated": 0, "deleted": 0}
        for i in items:
            key = (upn, i["id"])
            if i["removed"]:
                if self.calendar.pop(key, None):
                    st["deleted"] += 1
            else:
                st["updated" if key in self.calendar else "created"] += 1
                self.calendar[key] = i
        return st


class FakeGraph:
    def __init__(self):
        self.events, self.n, self.down, self.calls = {}, 0, False, 0
        self.outlook_changes = []     # pending delta items for inbound
        self.delta_calls = []

    def _chk(self):
        self.calls += 1
        if self.down:
            raise Transient("graph 503", retry_after=1, source="graph")

    def find_by_leave(self, upn, lid):
        self._chk()
        return next((k for k, (u, b) in self.events.items()
                     if u == upn and b["singleValueExtendedProperties"][0]["value"] == str(lid)), None)

    def create(self, upn, body):
        self._chk()
        self.n += 1
        self.events[f"E{self.n}"] = (upn, body)
        return f"E{self.n}"

    def update(self, upn, eid, body):
        self._chk()
        if eid not in self.events:
            return False
        self.events[eid] = (upn, body)
        return True

    def delete(self, upn, eid):
        self._chk()
        self.events.pop(eid, None)

    def calendar_delta(self, upn, delta_link=None, start=None, end=None):
        self._chk()
        self.delta_calls.append((delta_link, start))
        if delta_link == "EXPIRED":
            raise DeltaReset("410")
        page1, self.outlook_changes = self.outlook_changes[:2], self.outlook_changes[2:]
        yield page1, None
        page2, self.outlook_changes = self.outlook_changes, []
        yield page2, f"DL{len(self.delta_calls)}"


def leave(i, state="validate", wd="2026-11-24 10:00:00", **kw):
    d = dict(id=i, state=state, active=True, employee_id=[7, "Anna"], holiday_status_id=[1, "Paid Time Off"],
             request_date_from="2026-12-22", request_date_to="2026-12-24", request_unit_half=False,
             request_unit_hours=False, date_from="2026-12-22 07:00:00", date_to="2026-12-24 15:00:00",
             write_date=wd, employee=EMP)
    d.update(kw)
    return d


def ms_event(eid, subject="Meeting", **kw):
    e = {"id": eid, "subject": subject, "start": {"dateTime": "2026-12-01T09:00:00.0000000", "timeZone": "UTC"},
         "end": {"dateTime": "2026-12-01T10:00:00.0000000", "timeZone": "UTC"}, "isAllDay": False,
         "showAs": "busy", "sensitivity": "normal", "categories": [], "location": {"displayName": "Room 1"},
         "bodyPreview": "hi"}
    e.update(kw)
    return e


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        os.environ["MW_DB_PATH"] = os.path.join(self.tmp, "s.db")
        self.cfg = Config()
        self.st = Store(self.cfg.db_path)
        self.st.init()
        self.o, self.g = FakeOdoo(), FakeGraph()

    def drain(self):
        while True:
            job = self.st.claim()
            if not job:
                return
            try:
                worker.sync_leave(job["leave_id"], self.st, self.o, self.g, self.cfg)
                self.st.done(job["id"])
            except Transient as e:
                self.st.retry(job["id"], job["leave_id"], 3600, str(e))

    def cycle(self):
        poller.poll_once(self.st, self.o, self.cfg)
        self.drain()
        poller.report_once(self.st, self.o)


class OdooToOutlook(Base):
    def test_lifecycle(self):
        self.o.touch(1, leave(1, state="confirm"))
        self.cycle()
        self.assertEqual(self.g.events, {})
        self.assertEqual(self.o.status[1]["state"], "removed")
        self.o.touch(1, leave(1, wd="2026-11-24 10:05:00"))
        self.cycle()
        (eid, (upn, body)), = self.g.events.items()
        self.assertEqual(upn, "anna@ltech.dk")
        self.assertTrue(body["isAllDay"])
        self.assertEqual(body["end"]["dateTime"], "2026-12-25T00:00:00")  # exclusive end
        self.assertEqual(body["showAs"], "oof")
        self.assertEqual(self.o.status[1], {"leave_id": 1, "upn": "anna@ltech.dk", "event_id": eid,
                                            "state": "synced", "error": None})
        self.assertTrue(all(r["done"] for r in self.o.outbox_rows))
        calls = self.g.calls
        self.o.touch(1, leave(1, wd="2026-11-24 10:06:00"))   # irrelevant change → no Graph write
        self.cycle()
        self.assertEqual(self.g.calls, calls)
        self.o.touch(1, leave(1, wd="2026-11-24 10:10:00", request_date_to="2026-12-30"))
        self.cycle()
        self.assertEqual(list(self.g.events), [eid])
        self.assertEqual(self.g.events[eid][1]["end"]["dateTime"], "2026-12-31T00:00:00")
        self.o.touch(1, leave(1, active=False, wd="2026-11-24 10:20:00"))  # cancelled = archived in 17
        self.cycle()
        self.assertEqual(self.g.events, {})

    def test_deleted_in_odoo(self):
        self.o.touch(4, leave(4))
        self.cycle()
        self.o.touch(4, deleted=True)
        self.cycle()
        self.assertEqual(self.g.events, {})

    def test_graph_outage_then_recovery(self):
        self.g.down = True
        self.o.touch(2, leave(2))
        self.cycle()
        self.assertEqual(self.g.events, {})
        self.assertTrue(self.o.outbox_rows[0]["done"])   # durable locally → acked in Odoo
        self.assertEqual(self.st.c.execute("SELECT status FROM job").fetchone()[0], "pending")
        self.g.down = False
        self.st.c.execute("UPDATE job SET next_run_at=0")
        self.cycle()
        self.assertEqual(len(self.g.events), 1)

    def test_odoo_outage_poller_survives(self):
        self.o.down = True
        stop = threading.Event()
        t = threading.Thread(target=poller.run, args=(self.st, self.o, self.cfg, stop))
        t.start(); time.sleep(0.2); stop.set(); t.join()
        self.o.down = False
        self.o.touch(3, leave(3))
        self.cycle()
        self.assertEqual(len(self.g.events), 1)

    def test_permanent_error_reported_to_odoo(self):
        self.o.touch(8, leave(8, employee={"name": "X", "work_email": False, "tz": False}))
        poller.poll_once(self.st, self.o, self.cfg)
        stop = threading.Event()
        threading.Timer(0.5, stop.set).start()
        worker.run(self.st, self.o, self.g, self.cfg, stop)
        poller.report_once(self.st, self.o)
        self.assertEqual(self.o.status[8]["state"], "error")
        self.assertIn("work_email", self.o.status[8]["error"])

    def test_user_deleted_event_in_outlook_and_lost_state(self):
        self.o.touch(5, leave(5))
        self.cycle()
        self.g.events.clear()
        self.o.touch(5, leave(5, wd="2026-11-24 11:00:00", request_date_to="2026-12-27"))
        self.cycle()
        self.assertEqual(len(self.g.events), 1)
        self.st.c.execute("DELETE FROM leave_event")
        self.o.touch(5, leave(5, wd="2026-11-24 11:05:00"))
        self.cycle()
        self.assertEqual(len(self.g.events), 1)

    def test_half_day(self):
        self.o.touch(6, leave(6, request_unit_half=True))
        self.cycle()
        (_, (_, body)), = self.g.events.items()
        self.assertFalse(body["isAllDay"])
        self.assertEqual(body["start"], {"dateTime": "2026-12-22T07:00:00", "timeZone": "UTC"})

    def test_coalescing(self):
        self.st.enqueue(9); self.st.enqueue(9)
        self.assertEqual(self.st.c.execute("SELECT COUNT(*) FROM job WHERE status='pending'").fetchone()[0], 1)


class OutlookToOdoo(Base):
    def sync(self, now=None):
        inbound.sync_mailbox("anna@ltech.dk", self.st, self.o, self.g, self.cfg, now=now)

    def test_initial_and_incremental(self):
        self.g.outlook_changes = [ms_event("A"), ms_event("B"), ms_event("C", isAllDay=True)]
        self.sync()
        self.assertEqual(set(k[1] for k in self.o.calendar), {"A", "B", "C"})
        self.assertIsNotNone(self.g.delta_calls[0][1])          # initial call with window
        self.assertEqual(self.st.delta("anna@ltech.dk")["delta_link"], "DL1")
        self.g.outlook_changes = [ms_event("A", subject="Moved"), {"id": "B", "@removed": {"reason": "deleted"}}]
        self.sync()
        self.assertEqual(self.g.delta_calls[1][0], "DL1")       # incremental via deltaLink
        self.assertEqual(self.o.calendar[("anna@ltech.dk", "A")]["subject"], "Moved")
        self.assertNotIn(("anna@ltech.dk", "B"), self.o.calendar)

    def test_own_leave_events_skipped(self):
        self.g.outlook_changes = [ms_event("L", categories=["Odoo Time Off"]), ms_event("M")]
        self.sync()
        self.assertEqual(set(k[1] for k in self.o.calendar), {"M"})

    def test_odoo_down_keeps_old_token(self):
        self.g.outlook_changes = [ms_event("A")]
        self.sync()
        self.o.down = True
        self.g.outlook_changes = [ms_event("B")]
        with self.assertRaises(Transient):
            self.sync()
        self.assertEqual(self.st.delta("anna@ltech.dk")["delta_link"], "DL1")   # not advanced

    def test_expired_token_and_window_roll(self):
        self.st.set_delta("anna@ltech.dk", "EXPIRED", time.time())
        with self.assertRaises(DeltaReset):
            self.sync()
        self.st.set_delta("anna@ltech.dk", "DLx", time.time() - 8 * 86400)   # older than DELTA_RESET_DAYS
        self.sync()
        self.assertIsNone(self.g.delta_calls[-1][0])            # fresh window, not the old link

    def test_run_loop_handles_reset(self):
        self.st.set_delta("anna@ltech.dk", "EXPIRED", time.time())
        stop = threading.Event()
        threading.Timer(0.3, stop.set).start()
        inbound.run(self.st, self.o, self.g, self.cfg, stop)
        self.assertIsNone(self.st.delta("anna@ltech.dk"))       # dropped → full resync next cycle


if __name__ == "__main__":
    unittest.main()
